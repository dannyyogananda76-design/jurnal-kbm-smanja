import React, { useEffect, useState } from 'react';
import { Users, GraduationCap, UserCheck, Building2, BookOpen, Clock, Home, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

interface Stats {
  users: number;
  guru: number;
  siswa: number;
  kelas: number;
  mapel: number;
  jampel: number;
}

const statCards = [
  { key: 'users', label: 'USER', icon: Users, bg: 'bg-blue-500', darkBg: 'bg-blue-600' },
  { key: 'guru', label: 'GURU', icon: GraduationCap, bg: 'bg-red-500', darkBg: 'bg-red-600' },
  { key: 'siswa', label: 'SISWA', icon: UserCheck, bg: 'bg-green-500', darkBg: 'bg-green-600' },
  { key: 'kelas', label: 'KELAS', icon: Building2, bg: 'bg-amber-500', darkBg: 'bg-amber-600' },
  { key: 'mapel', label: 'MAPEL', icon: BookOpen, bg: 'bg-blue-700', darkBg: 'bg-blue-800' },
  { key: 'jampel', label: 'JAMPEL', icon: Clock, bg: 'bg-gray-800', darkBg: 'bg-gray-900' },
];

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ users: 0, guru: 0, siswa: 0, kelas: 0, mapel: 0, jampel: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      const [users, guru, siswa, kelas, mapel, jampel] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('guru').select('id', { count: 'exact', head: true }),
        supabase.from('siswa').select('id', { count: 'exact', head: true }),
        supabase.from('kelas').select('id', { count: 'exact', head: true }),
        supabase.from('mapel').select('id', { count: 'exact', head: true }),
        supabase.from('jam_pelajaran').select('id', { count: 'exact', head: true }),
      ]);
      setStats({
        users: users.count ?? 0,
        guru: guru.count ?? 0,
        siswa: siswa.count ?? 0,
        kelas: kelas.count ?? 0,
        mapel: mapel.count ?? 0,
        jampel: jampel.count ?? 0,
      });
      setLoading(false);
    };
    fetchStats();
  }, []);

  return (
    <div>
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <Home className="w-4 h-4" />
        <ChevronRight className="w-3 h-3" />
        <span className="text-gray-800 font-medium">Dashboard</span>
        <span className="ml-auto text-gray-400">Dashboard &gt; Dashboard</span>
      </div>

      <div className="flex items-baseline gap-3 mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <span className="text-sm text-gray-400 font-medium">Version 1.0</span>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {statCards.map(({ key, label, icon: Icon, bg, darkBg }) => (
          <div key={key} className={`${bg} rounded-xl overflow-hidden shadow-lg text-white`}>
            <div className={`${darkBg} p-4 flex items-center justify-center`}>
              <Icon className="w-9 h-9 text-white/80" />
            </div>
            <div className="p-3 text-center">
              <div className="text-2xl font-bold">
                {loading ? '...' : stats[key as keyof Stats]}
              </div>
              <div className="text-xs font-semibold opacity-80 tracking-wider">{label}</div>
              {key === 'siswa' && <div className="text-xs opacity-70">Orang</div>}
              {key === 'kelas' && <div className="text-xs opacity-70">Kelas</div>}
              {key === 'mapel' && <div className="text-xs opacity-70">Mapel</div>}
              {key === 'jampel' && <div className="text-xs opacity-70">Jam</div>}
              {key === 'users' && <div className="text-xs opacity-70">Orang</div>}
              {key === 'guru' && <div className="text-xs opacity-70">Orang</div>}
            </div>
          </div>
        ))}
      </div>

      {/* Info Aplikasi */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-800">Informasi Aplikasi</h2>
          <button className="text-gray-400 hover:text-gray-600 text-lg font-bold leading-none">−</button>
        </div>
        <div className="p-5">
          <table className="text-sm">
            <tbody className="space-y-2">
              {[
                ['Nama Aplikasi', 'JanDa (Jadwal & Agenda)'],
                ['Versi Aplikasi', 'Versi 1.0'],
                ['Database', 'PostgreSQL (Supabase)'],
                ['Developer', 'IT SMAN 1 Jatibarang'],
                ['Tahun Pelajaran', '2026/2027 - Semester Ganjil'],
              ].map(([label, value]) => (
                <tr key={label}>
                  <td className="py-1.5 pr-8 text-gray-500 font-medium w-44">{label}</td>
                  <td className="py-1.5 text-gray-700">
                    {label === 'Developer'
                      ? <span className="text-blue-500 font-medium">{value}</span>
                      : value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
